package test;

import java.awt.Color;


import java.awt.Component;
import java.awt.Frame;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.InputEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLCanvas;
import com.jogamp.opengl.fixedfunc.GLLightingFunc;
import com.jogamp.opengl.fixedfunc.GLMatrixFunc;
import com.jogamp.opengl.glu.GLU;
import com.jogamp.opengl.util.Animator;
import com.jogamp.opengl.util.FPSAnimator;
import com.jogamp.opengl.util.gl2.GLUT;
import com.leapmotion.leap.Bone;
import com.leapmotion.leap.Controller;
import com.leapmotion.leap.Finger;
import com.leapmotion.leap.Hand;
import com.leapmotion.leap.Vector;

public class SimpleScene implements GLEventListener{

	private int w=1024;//default if not fullscree
	private int h=768;
	
	private static int forward=KeyEvent.VK_W;
	private static int backward=KeyEvent.VK_S;
	private static int strafel=KeyEvent.VK_A;
	private static int strafer=KeyEvent.VK_D;
	private static int up=KeyEvent.VK_Z;
	private static int down=KeyEvent.VK_X;
	
	private static int centerl=KeyEvent.VK_Q;
	private static int centerr=KeyEvent.VK_E;
	private static int centerup=KeyEvent.VK_R;
	private static int centerdown=KeyEvent.VK_F;
	private static int centerforward=KeyEvent.VK_C;
	private static int centerbackward=KeyEvent.VK_V;
	
	private float camx,camy,camz;
	private float centerx,centery,centerz;
	
	private static float dvar=200;
	
    public static void main(String[] args) throws InterruptedException {
        GLProfile glp = GLProfile.getDefault();
        GLCapabilities caps = new GLCapabilities(glp);
        GLCanvas canvas = new GLCanvas(caps);
        canvas.setFocusable(true);
        canvas.requestFocus();
        Frame frame = new Frame("AWT Window Test");
        
        
        frame.setSize(200, 200);
        frame.add(canvas);
        
        frame.setVisible(true);
        
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });
        
        canvas.addGLEventListener(new SimpleScene());
       
        Animator animator = new Animator(canvas);
        animator.start();
        
        Controller c=new Controller();
        com.leapmotion.leap.Frame f=c.frame();
       //c.addListener(new TestListener());
        while(true)
        {
        	f=c.frame();
        	
        	hand=f.hands().get(0);
       
        	Thread.sleep(20);
        }
    }
    
    public static Hand hand;
		
	public void init(GLAutoDrawable drawable) {
		GL gl=drawable.getGL();
		GLU glu=new GLU();
	
		System.out.println(drawable.toString());
		gl.glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	
		((Component) drawable).addKeyListener(new KeyAdapter(){
			
			public void keyPressed(KeyEvent e){			
				System.out.println("fdsf");
				if(e.getKeyCode()==forward)camz-=0.1;
				if(e.getKeyCode()==backward)camz+=0.1;
				if(e.getKeyCode()==strafel)camx-=0.1;
				if(e.getKeyCode()==strafer)camx+=0.1;
				if(e.getKeyCode()==up)camy+=0.1;
				if(e.getKeyCode()==down)camy-=0.1;
				
				if(e.getKeyCode()==centerr)centerx+=0.1;
				if(e.getKeyCode()==centerl)centerx-=0.1;
				if(e.getKeyCode()==centerup)centery+=0.1;
				if(e.getKeyCode()==centerdown)centery-=0.1;
				if(e.getKeyCode()==centerforward)centerz-=0.1;
				if(e.getKeyCode()==centerbackward)centerz+=0.1;
			}
		});
		
	}

	public void dispose(GLAutoDrawable drawable) {
	}
	
	public void DrawAxis(float x,float y,float z,GL4 gl)
	{
		gl.glLineWidth(4);
		  ((GL2) gl).glBegin(GL.GL_LINES);
		  ((GL2) gl).glColor3f(x,y,z);
		  ((GL2) gl).glVertex3f(0,0,0);
		  ((GL2) gl).glVertex3f(x,y,z);
		  ((GL2) gl).glEnd();
	}
	
	public void DrawFinger(GL4 gl,Finger f)
	{
		GLUT a=new GLUT();
		((GLMatrixFunc) gl).glTranslatef(f.tipPosition().getX()/dvar, f.tipPosition().getY()/dvar-1.5f, f.tipPosition().getZ()/dvar);
		((GL2) gl).glColor3f(0,1,0);
		a.glutSolidCube((float) 0.05);
		((GLMatrixFunc) gl).glLoadIdentity();
		
		
		((GLMatrixFunc) gl).glTranslatef(f.bone(Bone.Type.TYPE_INTERMEDIATE).center().getX()/dvar, 
				f.bone(Bone.Type.TYPE_INTERMEDIATE).center().getY()/dvar-1.5f, 
				f.bone(Bone.Type.TYPE_INTERMEDIATE).center().getZ()/dvar);
		((GL2) gl).glColor3f(0,0,1);
		a.glutSolidCube((float) 0.05);
		((GLMatrixFunc) gl).glLoadIdentity();
		
		((GLMatrixFunc) gl).glTranslatef(f.bone(Bone.Type.TYPE_PROXIMAL).center().getX()/dvar, 
				f.bone(Bone.Type.TYPE_PROXIMAL).center().getY()/dvar-1.5f, 
				f.bone(Bone.Type.TYPE_PROXIMAL).center().getZ()/dvar);
		((GL2) gl).glColor3f(1,0,1);
		a.glutSolidCube((float) 0.05);
		((GLMatrixFunc) gl).glLoadIdentity();
		
		if(f.type()!=Finger.Type.TYPE_THUMB)
		{
		((GLMatrixFunc) gl).glTranslatef(f.bone(Bone.Type.TYPE_METACARPAL).center().getX()/dvar, 
				f.bone(Bone.Type.TYPE_METACARPAL).center().getY()/dvar-1.5f, 
				f.bone(Bone.Type.TYPE_METACARPAL).center().getZ()/dvar);
		((GL2) gl).glColor3f(1,0,1);
		a.glutSolidCube((float) 0.05);
		((GLMatrixFunc) gl).glLoadIdentity();
		}
	
	}
	
	public void DrawHand(GL4 gl,Hand h)
	{
		GLUT a=new GLUT();
		((GLMatrixFunc) gl).glLoadIdentity();
		((GLMatrixFunc) gl).glTranslatef(h.palmPosition().getX()/dvar, h.palmPosition().getY()/dvar-1.5f, h.palmPosition().getZ()/dvar);
		((GL2) gl).glColor3f(0,0,0);
		a.glutSolidCube((float) 0.1);
		
		System.out.println(h.palmPosition().getZ()/dvar);
		
		DrawFinger(gl,h.fingers().fingerType(Finger.Type.TYPE_THUMB).get(0));
		DrawFinger(gl,h.fingers().fingerType(Finger.Type.TYPE_INDEX).get(0));
		DrawFinger(gl,h.fingers().fingerType(Finger.Type.TYPE_MIDDLE).get(0));
		DrawFinger(gl,h.fingers().fingerType(Finger.Type.TYPE_PINKY).get(0));
		DrawFinger(gl,h.fingers().fingerType(Finger.Type.TYPE_RING).get(0));
	}

	public void display(GLAutoDrawable drawable) {
		GL4 gl=drawable.getGL().getGL4();
		GLU glu=new GLU();
		
		gl.glEnable(GL.GL_DEPTH_TEST);
		gl.glClear(GL.GL_COLOR_BUFFER_BIT|GL.GL_DEPTH_BUFFER_BIT);
		((GLMatrixFunc) gl).glLoadIdentity();
	
		glu.gluLookAt(camx,camy, camz, centerx,centery, centerz, 0, 1, 0);	
		  DrawAxis(1,0,0,gl);
		  DrawAxis(0,1,0,gl);
		  DrawAxis(0,0,-1,gl);
		  DrawHand(gl,hand);
		gl.glFlush();
		
	}


	public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {
		GL gl=drawable.getGL();
		GLU glu=new GLU();
		
		gl.glViewport(0,0, w, h);
		 ((GLMatrixFunc) gl).glMatrixMode(GLMatrixFunc.GL_PROJECTION);  
		   ((GLMatrixFunc) gl).glLoadIdentity();
		glu.gluPerspective(80.0f, (float)1, 0.1f, 100f);
		((GLMatrixFunc) gl).glMatrixMode(GLMatrixFunc.GL_MODELVIEW);  
		   ((GLMatrixFunc) gl).glLoadIdentity();
		  
			
	}
}