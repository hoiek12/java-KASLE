package test;

import com.leapmotion.leap.*;

public class TestListener extends Listener{

	SwipeGesture a;
	state s=TestListener.state.ready;
	
	public static boolean isgiyeok(Hand h)
	{
		Finger thumb=h.fingers().fingerType(Finger.Type.TYPE_THUMB).get(0);
		Finger index=h.fingers().fingerType(Finger.Type.TYPE_INDEX).get(0);
		
		float k2=thumb.direction().dot(index.direction());
		float k3=index.direction().getZ();
		
		if(thumb.isExtended()&&index.isExtended()&&k2<0.4&&k3>0.7)
			return true;
		
		return false;
		
	}
	
	public static boolean isnieun(Hand h)
	{
		Finger thumb=h.fingers().fingerType(Finger.Type.TYPE_THUMB).get(0);
		Finger index=h.fingers().fingerType(Finger.Type.TYPE_INDEX).get(0);
		
		float k2=thumb.direction().dot(index.direction());
		float k3=index.direction().getZ();
		
		if(thumb.isExtended()&&index.isExtended()&&k2<0.4&&k3<0.7)
			return true;
		
		return false;
		
	}
	
	public void onFrame(Controller c)
	{
		Frame f=c.frame();
		HandList hlist;
		Hand rhand=new Hand();
		hlist=f.hands();
	
		if(hlist.isEmpty())
		{
		}
		//no hand
		else if(hlist.count()>2)
		{
			
		}
		//hand more than 3
		else
		{
			for(int i=0;i<hlist.count();i++)
			{
				if(hlist.get(i).isRight())
					rhand=hlist.get(i);
			}
			//get right hand
			
			if(!rhand.isValid())
			{
				
			}
			//no right hand in frame
			
			else
			{
				if((this.s!=TestListener.state.ready)&&!isgiyeok(rhand)&&!isnieun(rhand))
				{
					this.s=TestListener.state.ready;
					System.out.println("state changed to ready");
				}
			
				else if(isgiyeok(rhand))
				{
					this.s=TestListener.state.giyeok;
					System.out.println("state changed to giyeok");
				}	
				else if(isnieun(rhand))
				{
					this.s=TestListener.state.nieun;
					System.out.println("state changed to nieun");
				}	
			}
			//right hand exist in frame
		}
		//one or two hand
	}
	
	public enum state
	{
		ready,
		giyeok,
		nieun,
		lieul
	}
}
