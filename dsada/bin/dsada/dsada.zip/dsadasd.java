package Quiz;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;  //adds Arrays utility from java library 
import java.util.List;  //adds List utility from java library 
import java.util.Scanner;  //adds Scanner utility from java library 
import java.util.Collections;  //adds Collections utility from java library

public class basic_practice {
       int correct=0, number, i =0;
       boolean time = true;//initializes scoring variables 
       String VowelQuestion,VowelAnswer,ConsonantQuestion,ConsonantAnswer,
             ConsonantVowelQuestion,ConsonantVowelAnswer;
       List Vowel_Question = new ArrayList();
       List Vowel_Answer = new ArrayList();
       List Consonant_Question = new ArrayList();
       List Consonant_Answer = new ArrayList();
       List Consonant_Vowel_Question = new ArrayList();
       List Consonant_Vowel_Answer = new ArrayList();
      String path = practice.class.getResource("").getPath();
      public void start_prac_basic(){  
                VowelList();  //assigns name of portion of program to build the collection of questions and answers 
                ConsonantList();
                Consonant_VowelList();
                Basic_askQuestion();//assigns name of portion of program to ask the questions 
      }
       public void VowelList() //start of bankList 
       { 
          try {
               BufferedReader Vowel_Question_file = new BufferedReader(new FileReader(path + "VowelQuestion"));
               BufferedReader Vowel_Answer_file = new BufferedReader(new FileReader(path + "VowelAnswer"));
               while((VowelQuestion = Vowel_Question_file.readLine()) != null){
                  {
                     Vowel_Question.add(new String(VowelQuestion));
                      i++;
                  }
               } 
               i = 0;
               while((VowelAnswer = Vowel_Answer_file.readLine()) != null){
                  {
                        Vowel_Answer.add(new String(VowelAnswer));
                        i++;
                  }
              } 
               Vowel_Question.add("��");
               Vowel_Answer.add("��");

            } catch (FileNotFoundException e) {//������ ����ó��
               e.printStackTrace();
               } 
               catch (IOException e) {
               // TODO Auto-generated catch block
                  e.printStackTrace();
               }
       }  
      //end of bankList 
       public void ConsonantList(){
          try {
               BufferedReader Consonant_Question_file = new BufferedReader(new FileReader(path + "ConsonantQuestion"));
               BufferedReader Consonant_Answer_file = new BufferedReader(new FileReader(path + "ConsonantAnswer"));
               while((ConsonantQuestion = Consonant_Question_file.readLine()) != null){
                  {
                     Consonant_Question.add(new String(ConsonantQuestion));
                      i++;
                  }
               } 
               i = 0;
               while((ConsonantAnswer = Consonant_Answer_file.readLine()) != null){
                  {
                     Consonant_Answer.add(new String(ConsonantAnswer));
                        i++;
                  }
              } 
               Consonant_Question.add("��");
               Consonant_Answer.add("��");

            } catch (FileNotFoundException e) {//������ ����ó��
               e.printStackTrace();
               } 
               catch (IOException e) {
               // TODO Auto-generated catch block
                  e.printStackTrace();
               }
       }  //end of bankList    
          
       }
       public void Consonant_VowelList(){
           for(int i = 0; i < 40; i++){
              if(i < 19){
                 Consonant_Vowel_Question.add(i,Vowel_Question.get(i));
                  Consonant_Vowel_Answer .add(i,Vowel_Answer.get(i));
              }
              else{
                 Consonant_Vowel_Question.add(i,Consonant_Question.get(i));
                  Consonant_Vowel_Answer .add(i,Consonant_Answer.get(i));

              }
           }
           Collections.shuffle(Consonant_Vowel_Question );  //shuffles the list 
           Collections.shuffle(Consonant_Vowel_Answer );  //shuffles the list 
        }
    
       public void Basic_askQuestion() //start of askQuestion 
       { //���⼭ �� �׸��� ������ 
          try(Scanner input = new Scanner(System.in)){
               //rest of your code
           System.out.println("********************************");  //prints heading top border 
           System.out.println(" Welcome to my Quiz Application");  //prints heading 
           System.out.println("********************************");  //prints heading bottom border 
           System.out.println("������ ��带 ��������: Vowel Consonant Consonant_VowelList");  //prints heading 
           String entered = input.nextLine();  //read input 
           if(entered.equals("Vowel")){// �̺��� ��ư���� �����ؾߵ� 
           for (number = 0; number < 19; number++){  //start of counter for loop (���� ���� ����)
              System.out.printf("%d. %s?%n", number + 1, Vowel_Question.get(number));  //prints question(�̰� �׸����� ����, �ƴϸ� ����� ����) 
               System.out.println("Please Write Your Answers:");  
               entered = input.nextLine();  //read input
               if (entered.compareTo(Vowel_Answer.get(number)) ==0){  //checks the users input 
                        System.out.println("*** Correct! ***"); 
                        correct = correct + 1;//counts number of correct answers 
                        continue;
                     }  //end of if 
               else{  //start of response for wrong answers 
                        System.out.println("--- Incorrect! ---");
                        continue;
                  }
               }
           }  //end of counter for loop 
           else if(entered.equals("Consonant")){//�� �κе� ��ư���� �����ؾߵ�
              for (number = 0; number < 21; number++)  //start of counter for loop (���� ���� ����)
                {  
                  System.out.printf("%d. %s?%n", number + 1, Consonant_Question.get(number));  //prints question(�̰� �׸����� ����, �ƴϸ� ����� ����) 
                    System.out.println("Please Write Your Answers:");
                    entered = input.nextLine();  //read input 
                   
                    if (entered.compareTo(Consonant_Answer.get(number))==0)  //checks the users input 
                    { 
                        System.out.println("*** Correct! ***");  //prints correct response 
                        correct = correct + 1;  //counts number of correct answers 
                    }  //end of if 
                    else{  //start of response for wrong answers 
                       System.out.println("--- Incorrect! ---");  //print the incorrect response
                    }
                  }
              }
              else if(entered.equals("Consonant_VowelList")){//�� �κе� ��ư���� �����ؾߵ�

                  for (number = 0; number < 40; number++)  //start of counter for loop (���� ���� ����)
                    {  

                        System.out.printf("%d. %s?%n", number + 1, Consonant_Vowel_Question.get(number));  //prints question(�̰� �׸����� ����, �ƴϸ� ����� ����) 
                        System.out.println("Please Write Your Answers:");  
                        entered = input.nextLine();  //read input 

                        if (entered.compareTo( Consonant_Vowel_Answer.get(number))==0)  //checks the users input 
                        { 
                            System.out.println("*** Correct! ***");  //prints correct response 
                            correct = correct + 1;  //counts number of correct answers 
                        }  //end of if 
                        else{  //start of response for wrong answers 
                           System.out.println("--- Incorrect! ---");  //print the incorrect response
                        }

                    }

            }
       }

           System.out.println("*******************");  //prints footer top border 
           System.out.printf(" Your score is %d/%d%n", correct, number);  //prints results 
           System.out.println("*******************");  //prints footer bottom border 
   }
}