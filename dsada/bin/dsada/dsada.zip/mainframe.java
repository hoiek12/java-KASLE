package dsada;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.CardLayout;
import java.awt.Color;

public class mainframe extends JFrame {

	private JPanel contentPane;
	private CardLayout cards = new CardLayout();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					mainframe frame = new mainframe();
					frame.setResizable(false);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public mainframe() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1024, 625);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(cards);
		mainpage mainpage_ = new mainpage(this);
		mainpage_.setBackground(Color.BLACK);
		contentPane.add(mainpage_,"main");
		contentPane.add(new submain(this),"submain");
		contentPane.add(new quizpanel(this),"quizpanel");
		contentPane.add(new test(this),"test");
	setVisible(true);
	}
	
	public void changepaneltosubmain(){
		cards.show(contentPane,"submain");
	}
	public void changepaneltoquiz(){
		cards.show(contentPane,"quizpanel");
	}
	public void gotomainpage(){
		cards.show(contentPane,"main");
	}
	public void gototest(){
		cards.show(contentPane,"test");
	}
}
