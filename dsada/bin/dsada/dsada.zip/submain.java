package dsada;

import java.awt.Frame;

import javax.swing.JPanel;
import javax.swing.JTextField;

import com.memetix.mst.language.Language;
import com.memetix.mst.translate.Translate;
import javax.swing.JLabel;
public class submain extends JPanel {
	private mainframe F;

	public submain(mainframe f) {
		F=f;
		setBounds(100, 100, 1008, 592);
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(12, 35, 433, 430);
		add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(457, 35, 444, 268);
		add(panel);
		setVisible(true);
		
	}
}
