This folder contains deprecated plain native libraries for platform macosx-universal, please use the native JAR files in the jar folder.
