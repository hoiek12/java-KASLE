This folder contains deprecated plain native libraries for platform solaris-i586, please use the native JAR files in the jar folder.
